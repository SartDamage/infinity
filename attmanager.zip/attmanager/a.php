<?php
  $i_array = explode(',',$argv[1]);
 // var_dump($i_array);
  foreach($i_array as $key=>$value)
  {
  //echo $key;
  echo $value;
	  } 
?>